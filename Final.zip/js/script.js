$(function () {
    $('[data-toggle="popover"]').popover()
});

$(document).ready(function () {
    $(function () {
        $('[data-toggle="popover"]').popover()
    });

    var myjSonObject0 = {
        "dataArray": [{
                "isSelected": "true",
                "nextDistance": 2,
                "title": "Зарегистрирован",
                "subTitle": "",
                "dateValue": "10:12", // 10:12
                "pointCnt": "27.09.2019",
                "bodyCnt": 'Отдать приоритезированный список трэков.'
            },
            {
                "isSelected": "",
                "nextDistance": 5,
                "title": "Назначен",
                "subTitle": "",
                "dateValue": "15:12", // 12:11
                "pointCnt": "27.09.2019",
                "bodyCnt": 'Назначен трэк №17'
            },
            {
                "isSelected": "",
                "nextDistance": 4,
                "title": "В работе",
                "subTitle": "",
                "dateValue": "35:12", // 12:11
                "pointCnt": "27.09.2019",
                "bodyCnt": 'Решаем задачи по трэку'
            },
            // {
            //     "isSelected": "",
            //     "nextDistance": 7,
            //     "title": "My First Point 3",
            //     "subTitle": "subTitle33333",
            //     "dateValue": "89:12", // 12:11
            //     "pointCnt": "p4",
            //     "bodyCnt": 'hi other text'
            // }
        ]
    };
    var myjSonObject1 = {
        "dataArray": [{
                "isSelected": "true",
                "nextDistance": 2,
                "title": "Зарегистрирована",
                "subTitle": '',
                "dateValue": "10:12", // 10:12
                "pointCnt": "09.09.2019",
                "bodyCnt": 'Прошу согласовать командировку на всероссийский конкурс "Цифровой прорыв"'
            },
            {
                "isSelected": "",
                "nextDistance": 2,
                "title": "Согласовано",
                "subTitle": '',
                "dateValue": "15:12", // 12:11
                "pointCnt": "12.09.2019",
                "bodyCnt": 'Командировка согласована. Можете заказывать билеты в корпоративной системе.'
            },
            {
                "isSelected": "",
                "nextDistance": 1,
                "title": "Оформлено",
                "subTitle": '',
                "dateValue": "20:12", // 12:11
                "pointCnt": "13.09.2019",
                "bodyCnt": 'Билеты и бронирование гостиницы оформлены.'
            },
            {
                "isSelected": "",
                "nextDistance": 5,
                "title": "Решено",
                "subTitle": '',
                "dateValue": "59:12", // 12:11
                "pointCnt": "26.09.2019",
                "bodyCnt": 'Прибыл в Казань'
            }
        ]
    };

    var myjSonDatas = [myjSonObject0, myjSonObject1];

    $('.myjtline').each(function (idx, elem) {
        $(elem).jTLine(getjTlineSettings(idx));
    });

    function getjTlineSettings(idx) {
        return {
            callType: 'jsonObject',
            structureObj: myjSonDatas[idx],
            distanceMode: 'fixDistance', // predefinedDistance , fixDistance               
            eventsMinDistance: 60,
            fixDistanceValue: 3,
            firstPointMargin: 0,

        }
    }

    var select2ru = {
        errorLoading: function () {
            return "Невозможно загрузить результаты"
        },
        inputTooLong: function (e) {
            var r = e.input.length - e.maximum,
                u = "Пожалуйста, введите на " + r + " символ";
            return u += n(r, "", "a", "ов"), u += " меньше"
        },
        inputTooShort: function (e) {
            var r = e.minimum - e.input.length,
                u = "Пожалуйста, введите ещё хотя бы " + r + " символ";
            return u += n(r, "", "a", "ов")
        },
        loadingMore: function () {
            return "Загрузка данных…"
        },
        maximumSelected: function (e) {
            var r = "Вы можете выбрать не более " + e.maximum + " элемент";
            return r += n(e.maximum, "", "a", "ов")
        },
        noResults: function () {
            return "Совпадений не найдено"
        },
        searching: function () {
            return "Поиск…"
        },
        removeAllItems: function () {
            return "Удалить все элементы"
        }
    }

    $('.js-request-category-select').select2({
        language: select2ru,
        width: '100%'
    });
});